/**
 * Esta clase representa la actividad principal de la aplicación,
 * que permite al usuario guardar un número de teléfono y un mensaje
 * en preferencias compartidas, y registra un receptor de transmisión
 * para detectar cambios en el estado del teléfono.
 */
package com.lmamlrg.broadcastreceiverytelefonia

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.telephony.TelephonyManager
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.lmamlrg.broadcastreceiverytelefonia.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    // Enlaces para acceder a las vistas de diseño
    private lateinit var binding : ActivityMainBinding
    // Receptor de transmisión personalizado para manejar eventos de telefonía
    private var elBroadcastReceiver : ElBroadcastReceiver? = null
    // Variables para almacenar el número de teléfono y el mensaje del usuario
    private var numero = ""
    private var mensaje = ""

    /**
     * Método llamado cuando se crea la actividad. Configura las vistas,
     * registra un receptor de transmisión y maneja la lógica de guardado
     * de preferencias compartidas.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Inicializa la vinculación de datos con el diseño de la actividad
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        // Obtiene la vista raíz
        val view = binding.root

        // Configura el filtro de intenciones para detectar cambios en el estado del teléfono
        val intentFilter = IntentFilter()
        intentFilter.addAction((TelephonyManager.ACTION_PHONE_STATE_CHANGED))
        // Crea e inicializa el receptor de transmisión
        elBroadcastReceiver = ElBroadcastReceiver()
        // Registra el receptor de transmisión
        registerReceiver(elBroadcastReceiver, intentFilter)

        // Configura el botón para guardar el número de teléfono y el mensaje
        binding.buttonSave.setOnClickListener{
            numero = binding.editNumeroTelefono.text.toString()
            mensaje = binding.editTextMessage.text.toString()

            // Inicia el servicio del receptor de servicio
            val intent = Intent(this, ServicerReceiver::class.java)
            startService(intent)

            // Almacena el número de teléfono y el mensaje en preferencias compartidas
            val sharedPreferences = getSharedPreferences( "Preferencias", Context.MODE_PRIVATE)
            val editor = sharedPreferences.edit()
            editor.putString("Numero:", numero)
            editor.putString("Mensaje:", mensaje)
            editor.apply()
        }
        // Inicializa el receptor de transmisión nuevamente
        elBroadcastReceiver= ElBroadcastReceiver()
    }

    /**
     * Método llamado cuando la actividad se vuelve visible para el usuario.
     * Registra el receptor de transmisión para detectar cambios en el estado del teléfono.
     */
    override fun onStart() {
        super.onStart()
        val intentFilter = IntentFilter()
        intentFilter.addAction(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        registerReceiver(elBroadcastReceiver, intentFilter)
    }

    /**
     * Método llamado cuando la actividad está a punto de ser destruida.
     * Libera recursos y anula el registro del receptor de transmisión.
     */
    override fun onDestroy() {
        super.onDestroy()
        elBroadcastReceiver?.let{
            unregisterReceiver(it)
        }
    }
}
