package com.lmamlrg.broadcastreceiverytelefonia

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import android.telephony.TelephonyManager.*
import android.util.Log

class ElBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        // Obtiene el estado del teléfono del intent recibido
        val estado = intent?.getStringArrayExtra(TelephonyManager.EXTRA_STATE)

        // Verifica si el estado corresponde a una llamada entrante
        if(estado!!.equals(TelephonyManager.EXTRA_STATE_RINGING)){
            // Obtiene el número de teléfono entrante del intent
            val phoneNumber= intent?.getStringExtra(EXTRA_INCOMING_NUMBER)

            // Accede a las preferencias compartidas para recuperar el número y el mensaje guardados
            val sharedPreferences = context?.getSharedPreferences("myPrefs",Context.MODE_PRIVATE)
            val savedPhoneNumber = sharedPreferences?.getString("phoneNumber" ,"")
            val savedMessage = sharedPreferences?.getString("message", "")

            // Compara el número entrante con el número guardado en las preferencias compartidas
            if (phoneNumber == savedPhoneNumber) {
                // Si hay una coincidencia, envía un mensaje de texto automático al número entrante
                val smsManager = SmsManager.getDefault()
                smsManager.sendTextMessage(phoneNumber, null, savedMessage, null, null)
                // Registra un mensaje en el log para indicar que el mensaje se envió correctamente
                Log.i("Respuesta","Mensaje enviado correctamente")
            } else {
                // Si no hay una coincidencia, registra un mensaje en el log indicando que hubo un problema al enviar el mensaje
                Log.i("Respuesta","Hubo un problema al enviar el mensaje")
            }
        }
    }
}
