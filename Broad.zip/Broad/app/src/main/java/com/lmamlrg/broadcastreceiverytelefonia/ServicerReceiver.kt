/**
 * Esta clase representa un servicio en segundo plano que se encarga de registrar
 * un receptor de transmisión para escuchar eventos relacionados con la telefonía.
 * Su función es proporcionar una continuidad en la detección de cambios en el
 * estado del teléfono, incluso cuando la actividad principal no está en primer plano.
 */
package com.lmamlrg.broadcastreceiverytelefonia

import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.os.IBinder
import android.telephony.TelephonyManager

class ServicerReceiver : Service() {
    // Receptor de transmisión para detectar eventos relacionados con la telefonía
    private lateinit var callReceiver: ElBroadcastReceiver
    // Bandera para controlar el estado del servicio
    private var isRunning = false

    /**
     * Método llamado cuando otro componente desea enlazarse con el servicio.
     * Devuelve null ya que este servicio no permite enlaces.
     */
    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    /**
     * Método llamado cuando el servicio se inicia.
     * Configura y registra el receptor de transmisión para eventos de telefonía.
     * Devuelve una constante que indica cómo el sistema debe comportarse si este
     * servicio se detiene repentinamente.
     */
    override fun onStartCommand(intent: Intent?, flags: Int, startID: Int): Int {
        // Si el servicio ya está en ejecución, se detiene y reinicia
        if (isRunning) {
            stopService(Intent(applicationContext, ServicerReceiver::class.java))
        }

        isRunning = true
        // Inicializa el receptor de transmisión
        callReceiver = ElBroadcastReceiver()
        // Configura el filtro de intenciones para detectar cambios en el estado del teléfono
        val intentFilter = IntentFilter()
        intentFilter.addAction(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        // Registra el receptor de transmisión
        registerReceiver(callReceiver, intentFilter)
        // Indica al sistema que el servicio debe continuar en ejecución incluso después de ser detenido
        return START_STICKY
    }

    /**
     * Método llamado cuando el servicio está a punto de ser destruido.
     * Libera recursos y anula el registro del receptor de transmisión.
     */
    override fun onDestroy() {
        super.onDestroy()
        // Anula el registro del receptor de transmisión
        unregisterReceiver(callReceiver)
        // Actualiza el estado del servicio
        isRunning = false
    }
}
